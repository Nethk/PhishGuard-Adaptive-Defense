// මේ ස්ක්‍රිප්ට් එක Gmail එකේ පේජ් එකක් ලෝඩ් වෙන හැම වෙලාවකම Run වෙනවා
function scanEmailContent() {
    // Gmail වල email body එක අල්ලගන්න (Class .a3s තමයි Gmail body එකට පාවිච්චි වෙන්නේ)
    const emailBodyElement = document.querySelector('.a3s');
    const senderElement = document.querySelector('.gD');

    if (!emailBodyElement || !senderElement) return;

    const emailBody = emailBodyElement.innerText;
    const sender = senderElement.getAttribute('email');

    // Backend එකට යවලා ස්කෑන් කරමු
    fetch('https://7d5d-111-223-183-153.ngrok-free.app/api/inspect_email', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ body: emailBody, sender: sender })
    })
    .then(r => r.json())
    .then(data => {
        if (data.is_phishing) {
            // අපි කලින් හදපු showChallengeBox එකම මෙතනත් පාවිච්චි කරන්න
            showChallengeBox(data.reasons, "GMAIL_SCAN");
        }
    });
}

// ඊමේල් එකක් ඕපන් කළාම ස්කෑන් වෙන්න
const observer = new MutationObserver(scanEmailContent);
observer.observe(document.body, { childList: true, subtree: true });