// කලින් සේව් කරපු ලින්ක් එකක් තියෙනව නම් පෙන්නන්න
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['pg_server_url'], (res) => {
    if (res.pg_server_url) {
      document.getElementById('serverUrl').value = res.pg_server_url;
    }
  });
});

// Save බොත්තම එබුවම
document.getElementById('saveBtn').addEventListener('click', () => {
  let url = document.getElementById('serverUrl').value.trim();

  // ළමයි ගොඩක් කරන වැරැද්දක් තමයි ලින්ක් එක අගට "/" ගහන එක. ඒක මකලා දාමු කෝඩ් එකෙන්ම:
  if (url.endsWith('/')) {
    url = url.slice(0, -1);
  }

  chrome.storage.local.set({ 'pg_server_url': url }, () => {
    const status = document.getElementById('status');
    status.textContent = '✅ URL Saved Successfully!';
    setTimeout(() => { status.textContent = ''; }, 2500);
  });
});